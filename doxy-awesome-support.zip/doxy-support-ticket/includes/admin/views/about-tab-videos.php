<div class="changelog">
	<div class="row">
		<div>			
			<div class="about-body">
				<h1>All of our informative videos in one place</h1>
				<br />
				<h4><em>Clicking the image below will take you a page on our website where you can view them all.</em></h4>
				<a href="https://getawesomesupport.com/videos/"> <img src="<?php echo WPAS_URL; ?>assets/admin/images/about/Videos-1016x651.png" alt="Videos Image Link"> </a>
			</div>
		</div>
	</div>
</div>	
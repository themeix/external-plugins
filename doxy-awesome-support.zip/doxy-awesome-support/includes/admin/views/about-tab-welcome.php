<div class="about-text"><b>Thanks for choosing Awesome Support!. At this point you should have already completed our setup wizard.  You can now use the tabs to the right to obtain more information, link to documentation and learn more about your new support system!</b></div>

<hr />	
<div>
	<div class="changelog">

		<div class="row">
			<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
				<div class="about-body">
					<a class="wpas-bundle-link" href="https://getawesomesupport.com/addons/startup-bundle/" target="_blank">
						<img src="<?php echo WPAS_URL; ?>assets/admin/images/StartupBundle-2_Blue.png" alt="Startup Bundle">	
					</a>		
				</div>
			</div>				
			<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">				
				<div class="about-body">
					<a class="wpas-bundle-link" href="https://getawesomesupport.com/addons/professional-bundle/" target="_blank">
						<img src="<?php echo WPAS_URL; ?>assets/admin/images/ProfessionalBundle-1_Red.png" alt="Professsional Bundle">	
					</a>		
				</div>
			</div>
		</div>
		<hr />						
	</div>
</div>


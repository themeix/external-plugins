jQuery(document).ready(function ($) {

	/**
	 * jQuery Select2
	 * http://select2.github.io/select2/
	 */
	if (jQuery().select2 && $('select.wpas-select2').length) {
		$('select.wpas-select2').select2();
	}

});